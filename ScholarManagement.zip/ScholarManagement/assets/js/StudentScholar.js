$(document).ready(function () {
    $('#add').click(function () {
        var scholarID = $('#scholarID').val();
        var ScholarType = $('#ScholarType').val();
        var Status = $('#Status').val();
        var Priority = $('#Priority').val();
        var Fname = $('#Fname').val();
        var Lname = $('#Lname').val();
        var MI = $('#MI').val();
        var Gender = $('#Gender').val();
        var BDate = $('#BDate').val();
        var Contact = $('#Contact').val();
        var School = $('#School').val();
        var Course = $('#Course').val();
        var Address = $('#Address').val();
        var Residency = $('#Residency').val();

        $.ajax({
            url: "studentInfo.php",
            type: "POST",
            
            data: {
                scholarID: scholarID,
                ScholarType: ScholarType,
                Status: Status,
                Priority: Priority,
                Fname: Fname,
                Lname: Lname,
                MI: MI,
                Gender: Gender,
                BDate: BDate,
                Contact: Contact,
                School: School,
                Course: Course,
                Address: Address,
                Residency: Residency
            },
            success: function (data, status, xhr) {
                $('#scholarID').val();
                $('#ScholarType').val();
                $('#Status').val();
                Pr$('#Priority').val();
                $('#Fname').val();
                $('#Lname').val();
                $('#MI').val();
                $('#Gender').val();
                $('#BDate').val();
                $('#School').val();
                $('#Course').val();
                $('#Address').val();
                $('#Residency').val();
                $.get("manageStudent.php", function (html) {
                    $("#table_content").html(html);
                });
                $('#records_content').fadeOut(1100).html(data);
            },
            error: function () {
                $('#records_content').fadeIn(3000).html('<div class="text-center">error here</div>');
            },
            beforeSend: function () {
                $('#records_content').fadeOut(700).html('<div class="text-center">Loading...</div>');
            }
        });
    });
});