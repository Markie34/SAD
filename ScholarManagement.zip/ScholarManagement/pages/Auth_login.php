<?php
session_start();

if(!empty($_POST)) {
    $_connection = mysqli_connect('localhost', 'root', '', 'barangaymuzon');
    if(!$_connection){
        die("Failed to connect to database ".mysqli_connect_error());
    }
    $username = mysqli_real_escape_string($_connection, $_POST['username']);
    $password = mysqli_real_escape_string($_connection, $_POST['password']);
    $hashedPassword =  password_hash($password, PASSWORD_BCRYPT);
    $query = "SELECT * FROM admin_account WHERE username = '$username' AND password = '$hashedPassword'";
    $result = mysqli_query($_connection, $query) or die (mysqli_error($_connection));
    if(mysqli_num_rows($result) > 0) {
        $_SESSION = mysqli_fetch_array($result);
        header('location:dashboard.php');
    } else {
        echo "<script>alert('invalid username/password');
            window.location.href= '../index.php';</script>";
    }
} else {
    header('location:../index.php');
}