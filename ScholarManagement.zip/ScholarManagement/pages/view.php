<?php
include 'header.php';
include 'sideMenu.php';
?>
<div class="main-panel ">
    <div class="content p-5 mt-2">
        <h2 class="text-2">STUDENTS RECORDS</h2>
        <table id="myTable" class="table table-striped-sm table-hover">
            <thead class="bg-gradient-primary text-white">
                <tr>
                    <th> ID</th>
                    <th> Firstname </th>
                    <th> Lastname </th>
                    <th> M.I </th>
                    <th> Gender </th>
                    <th> Action</th>
                </tr>
            </thead>
            <tbody>
			<?php
		require '../include/connection.php';
        $query = "SELECT * FROM studentinfo";
		$query_run = mysqli_query($conn, $query);
		if (mysqli_num_rows($query_run) > 0) {
			foreach ($query_run as $student) {
				?>
                <tr>
                    <td><?=$student['Scholar_ID']?></td>
                    <td><?=$student['First_Name'];?></td>
                    <td><?=$student['Last_Name'];?></td>
                    <td><?=$student['Middle_Initial'];?></td>
                    <td><?=$student['Gender'];?></td>
                    <td>
                        <button type="button" value="<?=$student['Scholar_ID'];?>"class="viewStudentBtn btn btn-info btn-sm">View</button>
                        <button type="button" value="<?=$student['Scholar_ID'];?>"class="editStudentBtn btn btn-success btn-sm">Edit</button>
                        <button type="button" value="<?=$student['Scholar_ID'];?>"class="deleteStudentBtn btn btn-danger btn-sm">Delete</button>
                    </td>
                </tr>
			<?php
			}
		}
			?>
            </tbody>
        </table>
    <!-- Edit Student Modal -->
<div class="modal fade" id="studentEditModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Student</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="updateStudent">
            <div class="modal-body">
			<div id="errorMessageUpdate" class="alert alert-warning d-none"></div>
			<div class="form-row d-flex flex-row justify-content-start">
                        <div class="form-group col-md-2 m-2">
                            <label for="ID">Scholar ID</label>
                            <input type="text" class="form-control form-control-sm " name="scholarID" id="scholarID"
                                placeholder="Enter Scholar ID" disabled>
                        </div>
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Scholar Type</label>
                            <select class="form-control form-control-sm" id="ScholarType" name="ScholarType">
                                <option selected disabled>Select Scholar Type</option>
                                <option>Senior High</option>
                                <option>College</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row d-flex flex-row justify-content-start">
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Status</label>
                            <select class="form-control form-control-sm" id="Status" name="Status">
                                <option selected disabled>Select Status</option>
                                <option>Active</option>
                                <option>Inactive</option>
                            </select>
                        </div>
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Priority</label>
                            <select class="form-control form-control-sm" id="Priority" name="Priority">
                                <option selected disabled>Select Priority</option>
                                <option>Passer</option>
                                <option>Imediate</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="fname">First Name</label>
                            <input type="text" class="form-control form-control-sm " id="Fname" name="Fname"
                                placeholder="Enter Firstname">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Last Name</label>
                            <input type="text" class="form-control form-control-sm " id="Lname" name="Lname"
                                placeholder="Enter Lastname">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Middle Initial</label>
                            <input type="text" class="form-control form-control-sm " id="MI" name="MI"
                                placeholder="Enter M.I">
                        </div>
                    </div>
                    <div class="form-row d-flex flex-row justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label>Gender</label>
                            <div class="col-sm">
                                <select class="form-control form-control-sm" id="Gender" name="Gender">
                                    <option disable>Select Gender</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Rather not say</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md m-2">
                            <label>Date of Birth</label>
                            <div class="col-sm">
                                <input type="date" class="form-control form-control-sm" id="BDate" name="BDate"
                                    placeholder="dd/mm/yyyy">
                            </div>
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Contact Number</label>
                            <input type="text" class="form-control form-control-sm " id="Contact" name="Contact"
                                placeholder="Enter Contact Number">

                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="fname">Present School</label>
                            <input type="text" class="form-control form-control-sm " id="School" name="School"
                                placeholder="Enter Present School">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="Course">Course</label>
                            <input type="text" class="form-control form-control-sm " id="Course" name="Course"
                                placeholder="Enter Course">
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control form-control-sm " id="Address" name="Address"
                                placeholder="Enter Address">
                        </div>
                        <div class="form-group col-md-4 m-2">
                            <label for="Residency">Years of Residency</label>
                            <input type="text" class="form-control form-control-sm " id="Residency" name="Residency"
                                placeholder="Enter Years of Residency">
                        </div>
                    </div>
                    <!-- <input type="button" name="save" class="btn btn-primary" value="Save to database" id="butsave"> -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Update Student</button>
            </div>
        </form>
        </div>
    </div>
</div>
    </div>
</div>

<script>
$(document).on('click', '.editStudentBtn', function() {
    var student_id = $(this).val();
    $.ajax({
		    type: "GET",
            url: "viewRecordsAJX.php?student_id=" + student_id,
            success: function(response) {
            var res = jQuery.parseJSON(response);
            if (res.status == 404) {
                alert(res.message);
            } else if (res.status == 200) {			
                $('#scholarID').val(res.data.Scholar_ID);
				$('#ScholarType').val(res.data.Scholar_Type);
				$('#Status').val(res.data.Status);
				$('#Priority').val(res.data.Priority);
                $('#Fname').val(res.data.First_Name);
                $('#Lname').val(res.data.Last_Name);
                $('#MI').val(res.data.Middle_Initial);
                $('#Gender').val(res.data.Gender);
				$('#BDate').val(res.data.B_Date);
				$('#Contact').val(res.data.Contact_Number);
				$('#School').val(res.data.Present_School);
				$('#Course').val(res.data.Course);
				$('#Address').val(res.data.Address);
				$('#Residency').val(res.data.ResidencyYear);
				$('#studentEditModal').modal('show');
                
            }
        }
    });
});
$(document).on('submit', '#updateStudent', function (e) {
            e.preventDefault();

            var formData = new FormData(this);
            formData.append("update_student", true);

            $.ajax({
                type: "POST",
                url: "updateRecordsAJX.php",
                data: formData,
                processData: true,
                contentType: false,
                success: function (response) {
                    var res = jQuery.parseJSON(response);
                    if(res.status == 422) {
                        $('#errorMessageUpdate').removeClass('d-none');
                        $('#errorMessageUpdate').text(res.message);

                    }else if(res.status == 200){

                        $('#errorMessageUpdate').addClass('d-none');

                        alertify.set('notifier','position', 'top-right');
                        alertify.success(res.message);
                        
                        $('#studentEditModal').modal('hide');
                        $('#updateStudent')[0].reset();

                        $('#myTable').load(location.href + " #myTable");

                    }else if(res.status == 500) {
                        alert(res.message);
                    }
                }
            });

        });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
include 'footer.php';
?>