<?php
include '../include/connection.php';
include 'header.php';
include 'sideMenu.php';
?>
<div class="main-panel ">
    <div class="content ">
        <div class="card">
            <div class="card-body p-5">
                <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                </div>
                <h4 class="card-title font-arial bold">ADD NEW STUDENTS</h4>
                <form id="fupForm" name="form1" method="POST">
                    <div class="form-row d-flex flex-row justify-content-start">
                        <div class="form-group col-md-2 m-2">
                            <label for="ID">Scholar ID</label>
                            <input type="text" class="form-control form-control-sm " name="scholarID" id="scholarID"
                                placeholder="Enter Scholar ID">
                        </div>
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Scholar Type</label>
                            <select class="form-control form-control-sm" id="ScholarType" name="ScholarType">
                                <option selected disabled>Select Scholar Type</option>
                                <option>Senior High</option>
                                <option>College</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row d-flex flex-row justify-content-start">
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Status</label>
                            <select class="form-control form-control-sm" id="Status" name="Status">
                                <option selected disabled>Select Status</option>
                                <option>Active</option>
                                <option>Inactive</option>
                            </select>
                        </div>
                        <div class="form-group col-md-2 m-2">
                            <label for="ScholarType">Priority</label>
                            <select class="form-control form-control-sm" id="Priority" name="Priority">
                                <option selected disabled>Select Priority</option>
                                <option>Passer</option>
                                <option>Imediate</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="fname">First Name</label>
                            <input type="text" class="form-control form-control-sm " id="Fname" name="Fname"
                                placeholder="Enter Firstname">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Last Name</label>
                            <input type="text" class="form-control form-control-sm " id="Lname" name="Lname"
                                placeholder="Enter Lastname">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Middle Initial</label>
                            <input type="text" class="form-control form-control-sm " id="MI" name="MI"
                                placeholder="Enter M.I">
                        </div>
                    </div>
                    <div class="form-row d-flex flex-row justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label>Gender</label>
                            <div class="col-sm">
                                <select class="form-control form-control-sm" id="Gender" name="Gender">
                                    <option disable>Select Gender</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Rather not say</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md m-2">
                            <label>Date of Birth</label>
                            <div class="col-sm">
                                <input type="date" class="form-control form-control-sm" id="BDate" name="BDate"
                                    placeholder="dd/mm/yyyy">
                            </div>
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="lname">Contact Number</label>
                            <input type="text" class="form-control form-control-sm " id="Contact" name="Contact"
                                placeholder="Enter Contact Number">

                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="fname">Present School</label>
                            <input type="text" class="form-control form-control-sm " id="School" name="School"
                                placeholder="Enter Present School">
                        </div>
                        <div class="form-group col-md m-2">
                            <label for="Course">Course</label>
                            <input type="text" class="form-control form-control-sm " id="Course" name="Course"
                                placeholder="Enter Course">
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-start ">
                        <div class="form-group col-md m-2">
                            <label for="Address">Address</label>
                            <input type="text" class="form-control form-control-sm " id="Address" name="Address"
                                placeholder="Enter Address">
                        </div>
                        <div class="form-group col-md-4 m-2">
                            <label for="Residency">Years of Residency</label>
                            <input type="text" class="form-control form-control-sm " id="Residency" name="Residency"
                                placeholder="Enter Years of Residency">
                        </div>
                    </div>
                    <input type="button" name="save" class="btn btn-primary" value="Save to database" id="butsave">
                </form>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    $('#butsave').on('click', function() {
        $("#butsave").attr("disabled", "disabled");
        var scholarID = $('#scholarID').val();
        var ScholarType = $('#ScholarType').val();
        var Status = $('#Status').val();
        var Priority = $('#Priority').val();
        var Fname = $('#Fname').val();
        var Lname = $('#Lname').val();
        var MI = $('#MI').val();
        var Gender = $('#Gender').val();
        var BDate = $('#BDate').val();
        var Contact = $('#Contact').val();
        var School = $('#School').val();
        var Course = $('#Course').val();
        var Address = $('#Address').val();
        var Residency = $('#Residency').val();
        if (scholarID != "" && ScholarType != "" && Status != "" && Priority != "" && Fname != "" &&
            Lname != "" && MI != "" &&
            Gender != "" && BDate != "" && Contact != "" && School != "" && Course != "" && Address !=
            "" && Residency != "") {
            $.ajax({
                url: "saveRecords.php",
                type: "POST",
                data: {
                    scholarID: scholarID,
                    ScholarType: ScholarType,
                    Status: Status,
                    Priority: Priority,
                    Fname: Fname,
                    Lname: Lname,
                    MI: MI,
                    Gender: Gender,
                    BDate: BDate,
                    Contact: Contact,
                    School: School,
                    Course: Course,
                    Address: Address,
                    Residency: Residency
                },
                cache: false,
                success: function(dataResult) {
                    var dataResult = JSON.parse(dataResult);
                    if (dataResult.statusCode == 200) {
                        $("#butsave").removeAttr("disabled");
                        $('#fupForm').find('input:text').val('');
                        $("#success").show();
                        $('#success').html('Data added successfully !');
                    } else if (dataResult.statusCode == 201) {
                        alert("Error occured !");
                    }
                }
            });
        } else {
            alert('Please fill all the field !');
        }
    });
});
</script>


<?php
include 'footer.php';
?>