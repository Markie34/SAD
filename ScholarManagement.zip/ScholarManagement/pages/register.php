<?php
    require_once  "../include/connection.php";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        function validData($x)
        {
            $x = trim($x);
            $x = stripslashes($x);
            $x = htmlspecialchars($x);
            return $x;
        }
        $username = $email = $password = "";
        $unameE=$emailE=$passE ="";
        $username = validData($_POST["username"]);
        $email = validData($_POST["email"]);
        $password = validData($_POST["password"]);        
        if (empty($username)) {
            $unameE = "Username field was empty!<BR>";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailE .= "Enter a valid Email<BR>";
        }
        if (empty($password)) {
            $passE = "Password field was empty!<BR>";
        }
        if (!empty($unameE) || !empty($emailE) || !empty($passE)) {
            $err = "Try again";
        } else {   
            $sql = "INSERT INTO `admin_account` (`Username`, `Email`, `Password`) VALUES (?,?,?)";
            $stmt = $conn->prepare($sql);
            $hashPassword=password_hash($password, PASSWORD_BCRYPT);
            $stmt->bind_param("sss", $username, $email,$hashPassword );
            if ($stmt->execute()) {
                header('Location:login.php');
            } else {
                $execE = "Invalid username and password!";
            }

        }       
}