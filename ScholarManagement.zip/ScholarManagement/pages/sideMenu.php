
<div class="container-scroller ">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row ">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="#"><img src="../assets/images/logo.svg" alt="logo" /></a>
          <a class="navbar-brand brand-logo-mini" href="#"><img src="../assets/images/logo-mini.svg" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block ">
          <h4 class="mt-4 ">Barangay Muzon Scholarship Assistance Records Management Website</h4>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../assets/images/mark.png" alt="image">
                  <span class="availability-status online"></span>
                </div>
                <div class="nav-profile-text">
                  <p class="mb-1 text-black">Mark</p>
                </div>
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item text-info" href="#">
                  <i class="mdi mdi-account me-2 text-success"></i> Profile </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-info" href="#">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="../assets/images/mark.png" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">Mark Feliciano</span>
                  <span class="text-secondary text-small">Software Engineer</span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./dashboard.php" >
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Students" aria-expanded="false" aria-controls="Students">
                <span class="menu-title">Students</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-account menu-icon"></i>
              </a>
              <div class="collapse" id="Students">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="addStudent.php">Add Students</a></li>
                  <li class="nav-item"> <a class="nav-link " href="view.php">Manage Students</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#ViewRecords" aria-expanded="false" aria-controls="ViewRecords">
                <span class="menu-title">View Records</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-eye menu-icon"></i>
              </a>
              <div class="collapse" id="ViewRecords">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="oldStudent.php">Old Students</a></li>
                  <li class="nav-item"> <a class="nav-link " href="newStudents.php">New Students</a></li>
                </ul>
              </div>
            </li>
      
            <!-- <li class="nav-item">
              <a class="nav-link" href="../pages/charts/chartjs.html">
                <span class="menu-title">Pending</span>
                <i class="mdi mdi-flag menu-icon"></i>
              </a>
            </li>   -->
            <li class="nav-item">
              <a class="nav-link" href="../pages/charts/chartjs.html">
                <span class="menu-title">Reports</span>
                <i class="mdi mdi-chart-bar menu-icon"></i>
              </a>
            </li>         
          </ul>
        </nav>
       