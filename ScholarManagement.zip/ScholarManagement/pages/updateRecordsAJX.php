<?php
include "../include/connection.php";
if(isset($_POST['update_student']))
{
    $studentID = mysqli_real_escape_string($conn, $_POST['scholarID']);
    $ScholarType = mysqli_real_escape_string($conn, $_POST['ScholarType']);
    $Status = mysqli_real_escape_string($conn, $_POST['Status']);
    $Priority = mysqli_real_escape_string($conn, $_POST['Priority']);
    $Fname = mysqli_real_escape_string($conn, $_POST['Fname']);
    $Lname = mysqli_real_escape_string($conn, $_POST['Lname']);
    $MI = mysqli_real_escape_string($conn, $_POST['MI']);
    $Gender = mysqli_real_escape_string($conn, $_POST['Gender']);
    $BDate = mysqli_real_escape_string($conn, $_POST['BDate']);
    $Contact = mysqli_real_escape_string($conn, $_POST['Contact']);
    $School = mysqli_real_escape_string($conn, $_POST['School']);
    $Course = mysqli_real_escape_string($conn, $_POST['Course']);
    $Address = mysqli_real_escape_string($conn, $_POST['Address']);
    $Residency = mysqli_real_escape_string($conn, $_POST['Residency']);
    // if( $studentID == NULL || $Status == NULL || $Priority == NULL || $Fname == NULL || $Lname == NULL || $MI == NULL || $Gender == NULL
    // || $BDate == NULL|| $Contact == NULL|| $School == NULL|| $Course == NULL|| $Address == NULL || $Residency == NULL)
    // {
    //     $res = [
    //         'status' => 422,
    //         'message' => 'All fields are required!'
    //     ];
    //     echo json_encode($res);
    //     return;
    // }
    $sql="UPDATE studentinfo SET Scholar_Type='$ScholarType',
    Status='$Status',Priority='$Priority',First_Name='$Fname',
    Last_Name='$Lname',Middle_Initial='$MI',Gender=' $Gender',B_Date='$BDate',
    Contact_Number='$Contact',Present_School='$School',Course='$Course',
    Address='$Address',ResidencyYear=' $Residency' WHERE Scholar_ID='$studentID'";
    $query_run = mysqli_query($conn, $sql);

    if($query_run)
    {
        $res = [
            'status' => 200,
            'message' => 'Student Updated Successfully'
        ];
        echo json_encode($res);
        return;
    }
    else
    {
        $res = [
            'status' => 500,
            'message' => 'Student Not Updated'
        ];
        echo json_encode($res);
        return;
    }
}

?>