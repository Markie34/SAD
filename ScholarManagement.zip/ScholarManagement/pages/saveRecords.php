<?php
include  '../include/connection.php';
$scholarID = $_POST['scholarID'];
$ScholarType = $_POST['ScholarType'];
$Status = $_POST['Status'];
$Priority = $_POST['Priority'];
$Fname = $_POST['Fname'];
$Lname = $_POST['Lname'];
$MI = $_POST['MI'];
$Gender = $_POST['Gender'];
$BDate = $_POST['BDate'];
$Contact = $_POST['Contact'];
$School = $_POST['School'];
$Course = $_POST['Course'];
$Address = $_POST['Address'];
$Residency = $_POST['Residency'];
$query = "INSERT INTO `studentinfo` (`Scholar_ID`, `Scholar_Type`, `Status`, `Priority`, `First_Name`, `Last_Name`, `Middle_Initial`, `Gender`, `B_Date`, `Contact_Number`,`Present_School`, `Course`, `Address`, `ResidencyYear`) 
 VALUES ('$scholarID', '$ScholarType', '$Status', '$Priority','$Fname', '$Lname', '$MI', '$Gender', '$BDate', '$Contact','$School', '$Course', '$Address', '$Residency')";
if (mysqli_query($conn, $query)) {
    echo json_encode(array("statusCode"=>200));
} 
else {
    echo json_encode(array("statusCode"=>201));
}
mysqli_close($conn);

?>