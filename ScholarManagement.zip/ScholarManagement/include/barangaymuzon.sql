-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2022 at 01:20 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `barangaymuzon`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `admin_ID` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `studentinfo`
--

CREATE TABLE `studentinfo` (
  `Scholar_ID` int(50) NOT NULL,
  `Scholar_Type` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Priority` varchar(50) NOT NULL,
  `First_Name` varchar(150) NOT NULL,
  `Last_Name` varchar(150) NOT NULL,
  `Middle_Initial` varchar(150) NOT NULL,
  `Gender` varchar(150) NOT NULL,
  `B_Date` date NOT NULL,
  `Contact_Number` varchar(150) NOT NULL,
  `Present_School` varchar(250) NOT NULL,
  `Course` varchar(250) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `ResidencyYear` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentinfo`
--

INSERT INTO `studentinfo` (`Scholar_ID`, `Scholar_Type`, `Status`, `Priority`, `First_Name`, `Last_Name`, `Middle_Initial`, `Gender`, `B_Date`, `Contact_Number`, `Present_School`, `Course`, `Address`, `ResidencyYear`) VALUES
(10249, 'Senior High', 'Active', 'Imediate', 'Mark', 'Feliciano', 'D', 'Male', '1131-05-31', '09071327209', 'Bulsu', 'EDUC', 'Manila', '2011'),
(42521, 'Senior High', 'Inactive', 'Passer', 'gagagaga', 'gagaga', 'D.', 'Female', '1221-01-12', '09071327209', 'Bulsu', 'EDUC', 'Manila', '2001'),
(66666, 'College', 'Inactive', 'Passer', 'jafaga', 'gagaga', 'ga', 'Female', '5222-02-04', '42624', 'ahhaha', 'hahaha', 'Brgy Muzon', '4222'),
(123456, 'College', 'Active', 'Passer', 'MARK', 'FELICIANO', 'L.', 'Male', '2002-03-31', '555555', 'Bulsu', 'BSIT', 'SAN JOSE', '2011'),
(1420249, 'Senior High', 'Active', 'Imediate', 'gagagaga', 'gagaga', 'D.', 'Female', '4222-02-04', '09071327209', 'najajaja', 'hahhaha', 'Manila', '4242'),
(12345642, 'Senior High', 'Active', 'Passer', 'Ry', 'Albao', 'D', 'Female', '4222-02-24', '09764645634', 'Bulsu', 'BSIT', 'Brgy Muzon', '2012');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`admin_ID`);

--
-- Indexes for table `studentinfo`
--
ALTER TABLE `studentinfo`
  ADD PRIMARY KEY (`Scholar_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
